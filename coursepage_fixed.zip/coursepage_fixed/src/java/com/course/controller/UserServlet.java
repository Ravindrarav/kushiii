package com.course.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import com.course.util.DBConnection;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        response.setContentType("text/html;charset=UTF-8");

        try (Connection conn = DBConnection.getConnection()) {

            // --- SIGNUP ---
            if ("signup".equals(action)) {
                String fullName  = request.getParameter("full_name");
                String username  = request.getParameter("username");
                String password  = request.getParameter("password");
                String email     = request.getParameter("email");

                // Check if username already exists
                try (PreparedStatement check = conn.prepareStatement(
                        "SELECT id FROM users WHERE username=?")) {
                    check.setString(1, username);
                    ResultSet rs = check.executeQuery();
                    if (rs.next()) {
                        response.sendRedirect("register.jsp?error=Username+already+taken");
                        return;
                    }
                }

                String sql = "INSERT INTO users (full_name, username, password, email) VALUES (?, ?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, fullName);
                    ps.setString(2, username);
                    ps.setString(3, password);
                    ps.setString(4, email);
                    ps.executeUpdate();
                    response.sendRedirect("success.jsp");
                }

            // --- LOGIN ---
            } else if ("login".equals(action)) {
                String user = request.getParameter("username");
                String pass = request.getParameter("password");
                String sql  = "SELECT * FROM users WHERE username=? AND password=?";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, user);
                    ps.setString(2, pass);
                    ResultSet rs = ps.executeQuery();
                    if (rs.next()) {
                        HttpSession session = request.getSession();
                        session.setAttribute("user", user);
                        response.sendRedirect("course_reg.jsp");
                    } else {
                        response.sendRedirect("login.jsp?error=Invalid+username+or+password");
                    }
                }

            // --- ENROLL ---
            } else if ("enroll".equals(action)) {
                HttpSession session = request.getSession(false);
                if (session == null || session.getAttribute("user") == null) {
                    response.sendRedirect("login.jsp");
                    return;
                }
                String currentUser    = (String) session.getAttribute("user");
                String selectedCourse = request.getParameter("course_name");

                if (selectedCourse == null || selectedCourse.trim().isEmpty()) {
                    response.sendRedirect("course_reg.jsp?error=Please+select+a+course");
                    return;
                }

                // Create registrations table if not exists (safety)
                String createTbl = "CREATE TABLE IF NOT EXISTS registrations ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY,"
                    + "username VARCHAR(100),"
                    + "course_name VARCHAR(200),"
                    + "enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
                try (Statement st = conn.createStatement()) {
                    st.executeUpdate(createTbl);
                }

                String sql = "INSERT INTO registrations (username, course_name) VALUES (?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, currentUser);
                    ps.setString(2, selectedCourse);
                    ps.executeUpdate();
                    String encoded = java.net.URLEncoder.encode(selectedCourse, "UTF-8");
                    response.sendRedirect("enroll_success.jsp?course=" + encoded);
                }

            } else {
                response.sendRedirect("index.html");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println(
                "<!DOCTYPE html><html><head><title>Error</title>"
                + "<style>body{font-family:sans-serif;padding:2rem;background:#fef2f2}"
                + ".box{background:#fff;border-radius:12px;padding:2rem;max-width:600px;border-left:4px solid #ef4444}"
                + "h2{color:#dc2626}pre{background:#f1f5f9;padding:1rem;border-radius:8px;font-size:.8rem;overflow:auto}"
                + "</style></head><body>"
                + "<div class='box'><h2>⚠ Server Error</h2>"
                + "<p style='color:#6b7280;margin:.5rem 0 1rem'>Something went wrong. See details below:</p>"
                + "<pre>" + e.getMessage() + "</pre>"
                + "<p style='margin-top:1rem'><a href='index.html' style='color:#4f46e5'>← Go back to Home</a></p>"
                + "</div></body></html>");
        }
    }
}
