package com.course.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        // Ensure the password matches your MySQL root password
        String url = "jdbc:mysql://localhost:3306/CourseDB";
        String user = "root";
        String pass = "root@123"; 
        return DriverManager.getConnection(url, user, pass);
    }
}