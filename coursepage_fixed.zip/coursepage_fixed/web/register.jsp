<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register | Course Portal</title>
<style>
:root{--brand:#4f46e5;--brand-dark:#3730a3;--brand-light:#e0e7ff;--text:#111827;--muted:#6b7280;--border:#e5e7eb}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',system-ui,sans-serif;background:linear-gradient(135deg,#4f46e5 0%,#06b6d4 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem}
.card{background:#fff;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.18);padding:2.5rem 2.2rem;max-width:420px;width:100%}
.back{display:inline-flex;align-items:center;gap:.4rem;color:#6b7280;text-decoration:none;font-size:.85rem;margin-bottom:1.5rem;transition:color .2s}
.back:hover{color:#4f46e5}
.logo{width:46px;height:46px;background:linear-gradient(135deg,#4f46e5,#06b6d4);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;margin-bottom:1rem}
h2{font-size:1.5rem;font-weight:700;color:#111827;margin-bottom:.3rem}
.sub{color:#6b7280;font-size:.875rem;margin-bottom:1.75rem}
label{display:block;font-size:.85rem;font-weight:600;color:#374151;margin-bottom:.4rem}
input{width:100%;padding:.75rem 1rem;border:1.5px solid #e5e7eb;border-radius:10px;font-size:.95rem;transition:all .2s;margin-bottom:1.1rem;background:#f9fafb}
input:focus{outline:none;border-color:#4f46e5;background:#fff;box-shadow:0 0 0 3px rgba(79,70,229,.12)}
.row{display:grid;grid-template-columns:1fr 1fr;gap:.75rem}
.btn-submit{width:100%;padding:.9rem;background:linear-gradient(135deg,#4f46e5,#3730a3);color:#fff;border:none;border-radius:10px;font-size:1rem;font-weight:600;cursor:pointer;transition:all .2s;margin-top:.25rem}
.btn-submit:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(79,70,229,.4)}
.footer{text-align:center;margin-top:1.5rem;font-size:.875rem;color:#6b7280}
.footer a{color:#4f46e5;text-decoration:none;font-weight:600}
.footer a:hover{text-decoration:underline}
</style>
</head>
<body>
<div class="card">
  <a href="index.html" class="back">← Back to Home</a>
  <div><div class="logo">✨</div></div>
  <h2>Create your account</h2>
  <p class="sub">Join the Course Portal and start learning today</p>

  <form action="UserServlet" method="post">
    <input type="hidden" name="action" value="signup">
    <label for="full_name">Full Name</label>
    <input type="text" id="full_name" name="full_name" placeholder="John Doe" required>
    <label for="username">Username</label>
    <input type="text" id="username" name="username" placeholder="johndoe123" required>
    <label for="email">Email Address</label>
    <input type="email" id="email" name="email" placeholder="name@example.com" required>
    <label for="password">Password</label>
    <input type="password" id="password" name="password" placeholder="Choose a strong password" required>
    <button type="submit" class="btn-submit">Create Account →</button>
  </form>
  <div class="footer">Already have an account? <a href="login.jsp">Login here</a></div>
</div>
</body>
</html>
