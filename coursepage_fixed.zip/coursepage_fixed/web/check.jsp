<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Server Check</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',system-ui,sans-serif;background:linear-gradient(135deg,#4f46e5,#06b6d4);min-height:100vh;display:flex;align-items:center;justify-content:center}
.card{background:#fff;border-radius:16px;padding:2.5rem;max-width:380px;width:90%;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.15)}
.dot{width:18px;height:18px;background:#10b981;border-radius:50%;display:inline-block;margin-bottom:1rem;box-shadow:0 0 0 6px #d1fae5}
h2{font-size:1.3rem;font-weight:700;color:#111827;margin-bottom:.5rem}
p{color:#6b7280;font-size:.875rem;margin-bottom:.3rem}
.time{font-family:monospace;font-size:.8rem;color:#4f46e5;background:#e0e7ff;padding:.3rem .8rem;border-radius:6px;display:inline-block;margin-top:.75rem}
a{display:inline-block;margin-top:1.5rem;color:#4f46e5;font-size:.875rem;font-weight:600;text-decoration:none}
a:hover{text-decoration:underline}
</style>
</head>
<body>
<div class="card">
  <div class="dot"></div>
  <h2>Server is Running</h2>
  <p>Jakarta EE application is live and responding.</p>
  <div class="time">🕐 <%= new java.util.Date() %></div>
  <br>
  <a href="index.html">← Go to Home</a>
</div>
</body>
</html>
