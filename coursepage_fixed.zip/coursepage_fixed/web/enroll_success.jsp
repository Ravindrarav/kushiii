<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    String course = request.getParameter("course");
    if (course == null || course.isEmpty()) course = "your selected course";
%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Enrollment Successful</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',system-ui,sans-serif;background:linear-gradient(135deg,#4f46e5 0%,#06b6d4 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem}
.card{background:#fff;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.18);padding:3rem 2.5rem;max-width:460px;width:100%;text-align:center}
.icon{width:72px;height:72px;background:#f0fdf4;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:2rem;margin-bottom:1.5rem;border:3px solid #10b981}
h1{font-size:1.6rem;font-weight:700;color:#111827;margin-bottom:.5rem}
.sub{color:#6b7280;font-size:.9rem;margin-bottom:1rem}
.course-badge{display:inline-block;background:#e0e7ff;color:#4f46e5;font-size:1.05rem;font-weight:700;padding:.6rem 1.5rem;border-radius:10px;margin:1rem 0 2rem}
.actions{display:flex;gap:.75rem;justify-content:center;flex-wrap:wrap}
.btn{padding:.8rem 1.6rem;border-radius:10px;font-size:.9rem;font-weight:600;text-decoration:none;transition:all .2s}
.btn-primary{background:linear-gradient(135deg,#4f46e5,#3730a3);color:#fff}
.btn-primary:hover{transform:translateY(-2px);box-shadow:0 6px 18px rgba(79,70,229,.4)}
.btn-outline{background:#fff;color:#4f46e5;border:2px solid #4f46e5}
.btn-outline:hover{background:#e0e7ff}
</style>
</head>
<body>
<div class="card">
  <div class="icon">🎉</div>
  <h1>Enrollment Successful!</h1>
  <p class="sub">You have been successfully enrolled in:</p>
  <div class="course-badge"><%= course %></div>
  <p style="color:#6b7280;font-size:.875rem;margin-bottom:2rem">Good luck with your studies! You can enroll in more courses from your dashboard.</p>
  <div class="actions">
    <a href="course_reg.jsp" class="btn btn-primary">Back to Courses</a>
    <a href="logout.jsp" class="btn btn-outline">Logout</a>
  </div>
</div>
</body>
</html>
