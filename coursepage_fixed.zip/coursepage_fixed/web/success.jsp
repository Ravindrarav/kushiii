<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registration Successful</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',system-ui,sans-serif;background:linear-gradient(135deg,#4f46e5 0%,#06b6d4 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem}
.card{background:#fff;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.18);padding:3rem 2.5rem;max-width:440px;width:100%;text-align:center}
.icon{width:72px;height:72px;background:#f0fdf4;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:2rem;margin-bottom:1.5rem;border:3px solid #10b981}
h1{font-size:1.6rem;font-weight:700;color:#111827;margin-bottom:.5rem}
p{color:#6b7280;font-size:.95rem;line-height:1.6;margin-bottom:2rem}
.btn{display:inline-block;padding:.85rem 2rem;background:linear-gradient(135deg,#4f46e5,#3730a3);color:#fff;text-decoration:none;border-radius:10px;font-size:.95rem;font-weight:600;transition:all .2s}
.btn:hover{transform:translateY(-2px);box-shadow:0 6px 18px rgba(79,70,229,.4)}
</style>
</head>
<body>
<div class="card">
  <div class="icon">✔</div>
  <h1>Account Created!</h1>
  <p>Your account has been created successfully. You can now log in to access your course dashboard.</p>
  <a href="login.jsp" class="btn">Login to Dashboard →</a>
</div>
</body>
</html>
