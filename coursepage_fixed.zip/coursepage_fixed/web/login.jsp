<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | Course Portal</title>
<style>
:root{--brand:#4f46e5;--brand-dark:#3730a3;--brand-light:#e0e7ff;--danger:#ef4444;--success:#10b981;--text:#111827;--muted:#6b7280;--border:#e5e7eb}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',system-ui,sans-serif;background:linear-gradient(135deg,#4f46e5 0%,#06b6d4 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem}
.card{background:#fff;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.18);padding:2.5rem 2.2rem;max-width:400px;width:100%}
.back{display:inline-flex;align-items:center;gap:.4rem;color:#6b7280;text-decoration:none;font-size:.85rem;margin-bottom:1.5rem;transition:color .2s}
.back:hover{color:#4f46e5}
.logo{width:46px;height:46px;background:linear-gradient(135deg,#4f46e5,#06b6d4);border-radius:12px;display:inline-flex;align-items:center;justify-content:center;font-size:1.3rem;margin-bottom:1rem}
h2{font-size:1.5rem;font-weight:700;color:#111827;margin-bottom:.3rem}
.sub{color:#6b7280;font-size:.875rem;margin-bottom:1.75rem}
.alert{padding:.75rem 1rem;border-radius:8px;font-size:.875rem;margin-bottom:1rem;border-left:3px solid}
.alert-error{background:#fef2f2;color:#dc2626;border-color:#ef4444}
.alert-success{background:#f0fdf4;color:#16a34a;border-color:#10b981}
label{display:block;font-size:.85rem;font-weight:600;color:#374151;margin-bottom:.4rem}
input[type=text],input[type=password]{width:100%;padding:.75rem 1rem;border:1.5px solid #e5e7eb;border-radius:10px;font-size:.95rem;transition:all .2s;margin-bottom:1.1rem;background:#f9fafb}
input:focus{outline:none;border-color:#4f46e5;background:#fff;box-shadow:0 0 0 3px rgba(79,70,229,.12)}
.btn-submit{width:100%;padding:.9rem;background:linear-gradient(135deg,#4f46e5,#3730a3);color:#fff;border:none;border-radius:10px;font-size:1rem;font-weight:600;cursor:pointer;transition:all .2s;margin-top:.25rem}
.btn-submit:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(79,70,229,.4)}
.footer{text-align:center;margin-top:1.5rem;font-size:.875rem;color:#6b7280}
.footer a{color:#4f46e5;text-decoration:none;font-weight:600}
.footer a:hover{text-decoration:underline}
</style>
</head>
<body>
<div class="card">
  <a href="index.html" class="back">← Back to Home</a>
  <div><div class="logo">🔐</div></div>
  <h2>Welcome back</h2>
  <p class="sub">Login to access your course dashboard</p>

  <% String error = request.getParameter("error");
     String msg   = request.getParameter("msg");
     if (error != null && !error.isEmpty()) { %>
    <div class="alert alert-error">⚠ <%= error %></div>
  <% } %>
  <% if (msg != null && !msg.isEmpty()) { %>
    <div class="alert alert-success">✔ <%= msg %></div>
  <% } %>

  <form action="UserServlet" method="post">
    <input type="hidden" name="action" value="login">
    <label for="username">Username</label>
    <input type="text" id="username" name="username" placeholder="Enter your username" required>
    <label for="password">Password</label>
    <input type="password" id="password" name="password" placeholder="Enter your password" required>
    <button type="submit" class="btn-submit">Login →</button>
  </form>
  <div class="footer">Don't have an account? <a href="register.jsp">Register here</a></div>
</div>
</body>
</html>
