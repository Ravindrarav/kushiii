<%@page import="java.sql.*"%>
<%@page import="com.course.util.DBConnection"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin | Registered Users</title>
<style>
:root{--brand:#4f46e5;--text:#111827;--muted:#6b7280;--border:#e5e7eb;--bg:#f1f5f9}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);min-height:100vh}
nav{background:#fff;border-bottom:1px solid var(--border);padding:.9rem 2rem;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 8px rgba(0,0,0,.06)}
.nav-brand{font-weight:700;color:#111827;font-size:1.05rem;display:flex;align-items:center;gap:.5rem}
.nav-brand span{width:32px;height:32px;background:linear-gradient(135deg,#4f46e5,#06b6d4);border-radius:8px;display:inline-flex;align-items:center;justify-content:center;font-size:.9rem}
.nav-back{color:#4f46e5;text-decoration:none;font-size:.875rem;font-weight:600}
.nav-back:hover{text-decoration:underline}
.main{max-width:800px;margin:2.5rem auto;padding:0 1rem}
.page-title{font-size:1.5rem;font-weight:700;color:#111827;margin-bottom:.4rem}
.page-sub{color:#6b7280;font-size:.9rem;margin-bottom:2rem}
.card{background:#fff;border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,.07);overflow:hidden}
table{width:100%;border-collapse:collapse}
thead{background:linear-gradient(135deg,#4f46e5,#3730a3)}
thead th{padding:1rem 1.25rem;text-align:left;color:#fff;font-size:.85rem;font-weight:600;letter-spacing:.03em}
tbody tr{border-bottom:1px solid #f1f5f9;transition:background .15s}
tbody tr:hover{background:#f8faff}
tbody tr:last-child{border-bottom:none}
td{padding:.9rem 1.25rem;font-size:.875rem;color:#374151}
td:first-child{font-weight:600;color:#4f46e5}
.avatar{width:32px;height:32px;border-radius:50%;background:#e0e7ff;color:#4f46e5;display:inline-flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;margin-right:.5rem;vertical-align:middle}
.empty{padding:3rem;text-align:center;color:#6b7280;font-size:.9rem}
.error-msg{padding:1rem 1.25rem;background:#fef2f2;color:#dc2626;font-size:.875rem;border-left:3px solid #ef4444}
</style>
</head>
<body>

<nav>
  <div class="nav-brand"><span>🎓</span> Course Portal — Admin</div>
  <a href="course_reg.jsp" class="nav-back">← Back to Dashboard</a>
</nav>

<div class="main">
  <div class="page-title">Registered Users</div>
  <div class="page-sub">All users who have signed up on the portal.</div>

  <div class="card">
    <%
      try (Connection conn = DBConnection.getConnection();
           Statement st = conn.createStatement();
           ResultSet rs = st.executeQuery("SELECT * FROM users ORDER BY id DESC")) {

        boolean hasRows = false;
    %>
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Full Name</th>
          <th>Username</th>
          <th>Email</th>
        </tr>
      </thead>
      <tbody>
    <%
        while (rs.next()) {
            hasRows = true;
            String initials = rs.getString("full_name").trim().length() > 0 ?
                String.valueOf(rs.getString("full_name").trim().charAt(0)).toUpperCase() : "?";
    %>
        <tr>
          <td><%= rs.getInt("id") %></td>
          <td>
            <span class="avatar"><%= initials %></span>
            <%= rs.getString("full_name") %>
          </td>
          <td><%= rs.getString("username") %></td>
          <td><%= rs.getString("email") %></td>
        </tr>
    <%
        }
        if (!hasRows) {
    %>
        <tr><td colspan="4" class="empty">No registered users yet.</td></tr>
    <%
        }
    %>
      </tbody>
    </table>
    <%
      } catch (Exception e) {
    %>
    <div class="error-msg">⚠ Database error: <%= e.getMessage() %></div>
    <%
      }
    %>
  </div>
</div>

</body>
</html>
