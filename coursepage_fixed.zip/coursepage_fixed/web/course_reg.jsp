<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    if (session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    String username = (String) session.getAttribute("user");
%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard | Course Registration</title>
<style>
:root{--brand:#4f46e5;--brand-dark:#3730a3;--brand-light:#e0e7ff;--accent:#06b6d4;--success:#10b981;--text:#111827;--muted:#6b7280;--border:#e5e7eb;--bg:#f1f5f9}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);min-height:100vh}
nav{background:#fff;border-bottom:1px solid var(--border);padding:.9rem 2rem;display:flex;justify-content:space-between;align-items:center;position:sticky;top:0;z-index:10;box-shadow:0 2px 8px rgba(0,0,0,.06)}
.nav-brand{display:flex;align-items:center;gap:.6rem;font-weight:700;color:#111827;font-size:1.05rem}
.nav-brand span{width:32px;height:32px;background:linear-gradient(135deg,#4f46e5,#06b6d4);border-radius:8px;display:inline-flex;align-items:center;justify-content:center;font-size:.9rem}
.nav-right{display:flex;align-items:center;gap:1rem}
.welcome{font-size:.875rem;color:#6b7280}
.welcome strong{color:#4f46e5}
.logout{color:#ef4444;text-decoration:none;font-size:.875rem;font-weight:600;padding:.4rem .9rem;border:1.5px solid #ef4444;border-radius:8px;transition:all .2s}
.logout:hover{background:#ef4444;color:#fff}
.main{max-width:680px;margin:2.5rem auto;padding:0 1rem}
.page-title{font-size:1.5rem;font-weight:700;color:#111827;margin-bottom:.4rem}
.page-sub{color:#6b7280;font-size:.9rem;margin-bottom:2rem}
.alert{padding:.85rem 1rem;border-radius:10px;font-size:.875rem;margin-bottom:1.5rem;border-left:3px solid}
.alert-success{background:#f0fdf4;color:#16a34a;border-color:#10b981}
.card{background:#fff;border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,.07);padding:2rem;margin-bottom:1.5rem}
.card h3{font-size:1.05rem;font-weight:600;color:#111827;margin-bottom:1.25rem;display:flex;align-items:center;gap:.5rem}
.courses-grid{display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-bottom:1.5rem}
.course-option{border:2px solid #e5e7eb;border-radius:10px;padding:1rem;cursor:pointer;transition:all .2s;display:flex;align-items:center;gap:.75rem;background:#f9fafb}
.course-option:hover{border-color:#4f46e5;background:#e0e7ff}
.course-option input[type=radio]{display:none}
.course-option.selected{border-color:#4f46e5;background:#e0e7ff}
.course-icon{width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0}
.course-name{font-size:.9rem;font-weight:600;color:#111827}
.course-tag{font-size:.72rem;color:#6b7280;margin-top:.1rem}
.btn-enroll{width:100%;padding:1rem;background:linear-gradient(135deg,#4f46e5,#3730a3);color:#fff;border:none;border-radius:10px;font-size:1rem;font-weight:600;cursor:pointer;transition:all .2s}
.btn-enroll:hover{transform:translateY(-1px);box-shadow:0 6px 18px rgba(79,70,229,.4)}
.admin-link{text-align:center;margin-top:1.5rem}
.admin-link a{color:#6b7280;font-size:.8rem;text-decoration:none}
.admin-link a:hover{color:#4f46e5;text-decoration:underline}
@media(max-width:500px){.courses-grid{grid-template-columns:1fr}}
</style>
</head>
<body>

<nav>
  <div class="nav-brand"><span>🎓</span> Course Portal</div>
  <div class="nav-right">
    <span class="welcome">Hello, <strong><%= username %></strong></span>
    <a href="logout.jsp" class="logout">Logout</a>
  </div>
</nav>

<div class="main">
  <div class="page-title">Course Registration</div>
  <div class="page-sub">Select a course below and click Enroll to get started.</div>

  <% if(request.getParameter("success") != null) { %>
    <div class="alert alert-success">✔ <%= request.getParameter("success") %></div>
  <% } %>

  <div class="card">
    <h3>📚 Available Courses</h3>
    <form action="UserServlet" method="post" id="enrollForm">
      <input type="hidden" name="action" value="enroll">
      <div class="courses-grid" id="courseGrid">

        <label class="course-option" onclick="selectCourse(this,'Java Jakarta EE')">
          <input type="radio" name="course_name" value="Java Jakarta EE">
          <div class="course-icon" style="background:#e0e7ff">☕</div>
          <div><div class="course-name">Advanced Java</div><div class="course-tag">Jakarta EE • Backend</div></div>
        </label>

        <label class="course-option" onclick="selectCourse(this,'Python Django')">
          <input type="radio" name="course_name" value="Python Django">
          <div class="course-icon" style="background:#d1fae5">🐍</div>
          <div><div class="course-name">Python Django</div><div class="course-tag">Web Framework • Backend</div></div>
        </label>

        <label class="course-option" onclick="selectCourse(this,'MySQL Database')">
          <input type="radio" name="course_name" value="MySQL Database">
          <div class="course-icon" style="background:#fef3c7">🗄️</div>
          <div><div class="course-name">MySQL Database</div><div class="course-tag">SQL • Data Storage</div></div>
        </label>

        <label class="course-option" onclick="selectCourse(this,'C Programming')">
          <input type="radio" name="course_name" value="C Programming">
          <div class="course-icon" style="background:#fce7f3">⚙️</div>
          <div><div class="course-name">C Programming</div><div class="course-tag">Systems • Fundamentals</div></div>
        </label>

        <label class="course-option" onclick="selectCourse(this,'Linux Commands')">
          <input type="radio" name="course_name" value="Linux Commands">
          <div class="course-icon" style="background:#f0fdf4">🐧</div>
          <div><div class="course-name">Linux Commands</div><div class="course-tag">OS • Terminal</div></div>
        </label>

        <label class="course-option" onclick="selectCourse(this,'HTML CSS JS')">
          <input type="radio" name="course_name" value="HTML CSS JS">
          <div class="course-icon" style="background:#eff6ff">🌐</div>
          <div><div class="course-name">HTML / CSS / JS</div><div class="course-tag">Web • Frontend</div></div>
        </label>

      </div>
      <button type="submit" class="btn-enroll">Enroll Now →</button>
    </form>
  </div>

  <div class="admin-link"><a href="view_users.jsp">Admin: View Registered Users →</a></div>
</div>

<script>
function selectCourse(el, val) {
  document.querySelectorAll('.course-option').forEach(o => o.classList.remove('selected'));
  el.classList.add('selected');
  el.querySelector('input[type=radio]').checked = true;
}
document.getElementById('enrollForm').addEventListener('submit', function(e) {
  if (!document.querySelector('input[type=radio]:checked')) {
    e.preventDefault();
    alert('Please select a course before enrolling.');
  }
});
</script>
</body>
</html>
