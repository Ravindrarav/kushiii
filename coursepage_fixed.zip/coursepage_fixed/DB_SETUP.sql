-- ============================================
-- Course Portal - Database Setup Script
-- Run this in MySQL before deploying the app
-- ============================================

-- 1. Create the database
CREATE DATABASE IF NOT EXISTS CourseDB
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE CourseDB;

-- 2. Users table
CREATE TABLE IF NOT EXISTS users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    full_name  VARCHAR(150)  NOT NULL,
    username   VARCHAR(100)  NOT NULL UNIQUE,
    password   VARCHAR(255)  NOT NULL,
    email      VARCHAR(200)  NOT NULL,
    created_at TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- 3. Registrations table (course enrolments)
CREATE TABLE IF NOT EXISTS registrations (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(100) NOT NULL,
    course_name VARCHAR(200) NOT NULL,
    enrolled_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (username) REFERENCES users(username) ON DELETE CASCADE
);

-- 4. Optional: insert a test admin user (password: admin123)
-- INSERT INTO users (full_name, username, password, email)
-- VALUES ('Admin User', 'admin', 'admin123', 'admin@portal.com');

SELECT 'Database setup complete!' AS status;
