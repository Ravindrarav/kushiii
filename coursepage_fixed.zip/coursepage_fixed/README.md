# Course Portal — Setup & Deployment Guide

A Jakarta EE student course registration web application.

## Tech Stack
- **Java** — Jakarta EE 10 (Servlets + JSP)
- **Server** — Apache Tomcat 10.x
- **Database** — MySQL 8+
- **IDE** — NetBeans (Ant build)

---

## Step 1 — MySQL Setup

Run the included `DB_SETUP.sql` in MySQL Workbench or terminal:

```sql
mysql -u root -p < DB_SETUP.sql
```

This creates:
- Database: `CourseDB`
- Table: `users` (id, full_name, username, password, email, created_at)
- Table: `registrations` (id, username, course_name, enrolled_at)

---

## Step 2 — Configure DB Password

Edit `src/java/com/course/util/DBConnection.java`:

```java
String url  = "jdbc:mysql://localhost:3306/CourseDB";
String user = "root";
String pass = "YOUR_MYSQL_PASSWORD";   // <-- change this
```

---

## Step 3 — Deploy on Tomcat

1. Open the project in **NetBeans**
2. Right-click project → **Clean and Build**
3. Right-click project → **Run** (deploys to Tomcat)
4. Visit: `http://localhost:8080/courespage/`

Or manually build the WAR and copy to Tomcat's `webapps/` folder.

---

## Page Flow

```
index.html  →  register.jsp  →  [UserServlet?action=signup]  →  success.jsp
            →  login.jsp     →  [UserServlet?action=login]   →  course_reg.jsp
                                                                →  [UserServlet?action=enroll] → enroll_success.jsp
                                                                →  view_users.jsp  (admin)
                                                                →  logout.jsp  →  login.jsp
```

---

## All Pages

| Page | Description |
|------|-------------|
| `index.html` | Landing / welcome page |
| `login.jsp` | User login form |
| `register.jsp` | New account registration |
| `success.jsp` | Account created confirmation |
| `course_reg.jsp` | Dashboard — select & enroll in course |
| `enroll_success.jsp` | Course enrollment confirmation |
| `view_users.jsp` | Admin — list all registered users |
| `logout.jsp` | Invalidates session, redirects to login |
| `check.jsp` | Server health check |

---

## Notes

- Passwords are stored in plain text (for demo). Add BCrypt for production.
- `logout.jsp` invalidates the session and redirects to login.
- Session timeout is set to 30 minutes (`web.xml`).
